package com.example.arshii.attendencesystem;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Base64;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private Button mCapturePhoto;
    private String encoded_string, image_name;
    private Bitmap bitmap;
    private File file;
    private Uri image_uri;
    private EditText ipAdress;
    private String ip;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ipAdress = (EditText) findViewById(R.id.serverIp);
        mCapturePhoto = (Button) findViewById(R.id.captureImage);

        mCapturePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (!TextUtils.isEmpty(ipAdress.getText())){
                    ip = ipAdress.getText().toString();
                    capturePhoto();
                }
                else{
                    Toast.makeText(MainActivity.this, "Enter ip adress", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    private void capturePhoto() {

        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        getFileUri();
        cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT,image_uri);
        startActivityForResult(cameraIntent,1);


    }

    private void getFileUri() {

        image_name = "arshiii.jpg";
        file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)+
                File.separator + image_name
        );
        image_uri = Uri.fromFile(file);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if(requestCode == 1 && resultCode == RESULT_OK){
            new encodeImage().execute();
        }
    }

    private class encodeImage extends AsyncTask<Void,Void,Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            bitmap = BitmapFactory.decodeFile(image_uri.getPath());
            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.JPEG,100,stream);
            byte[] byteArray = stream.toByteArray();
            encoded_string = Base64.encodeToString(byteArray,0);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            makeConnectionRequest();
        }
        private void makeConnectionRequest() {
            RequestQueue requestQueue = Volley.newRequestQueue(MainActivity.this);
            StringRequest request = new StringRequest(Request.Method.POST, "http://"+ip+"/Android/connection.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {

                            Toast.makeText(MainActivity.this, "Successfull uploaded", Toast.LENGTH_SHORT).show();

                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Toast.makeText(MainActivity.this, "Failed", Toast.LENGTH_SHORT).show();

                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    HashMap<String,String> map = new HashMap<>();
                    map.put("encoded_string",encoded_string);
                    map.put("image_name",image_name);
                    return map;
                }
            };
            requestQueue.add(request);
        }
    }


}
